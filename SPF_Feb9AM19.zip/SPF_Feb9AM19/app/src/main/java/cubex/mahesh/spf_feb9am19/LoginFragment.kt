package cubex.mahesh.spf_feb9am19

import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import kotlinx.android.synthetic.main.login.view.*

class  LoginFragment : Fragment()
{
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var v = inflater.inflate(R.layout.login,
                            container,false)

        v.register.setOnClickListener {
            var fManager  = fragmentManager
            var tx = fManager?.beginTransaction()
            tx?.replace(R.id.frame1, RegistrationFragment())
            tx?.commit()
        }

        v.login.setOnClickListener {
            var spf = activity?.getSharedPreferences(
                "and9amfeb19", Context.MODE_PRIVATE)
            var email = spf?.getString("email","no value")
            var pass = spf?.getString("pass","no value")

            if(email.equals(v.et1.text.toString()) &&
                        pass.equals(v.et2.text.toString())){

                var fManager  = fragmentManager
                var tx = fManager?.beginTransaction()
                tx?.replace(R.id.frame1, WelcomeFragment())
                tx?.commit()

            }else{
                Toast.makeText(activity, " Invalid User",
                    Toast.LENGTH_LONG).show()
            }
        }


        return v
    }
}